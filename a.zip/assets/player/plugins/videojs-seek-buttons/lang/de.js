videojs.addLanguage('de', {
  "Seek forward {{seconds}} seconds": "Vorwärts {{seconds}} Sekunden",
  "Seek back {{seconds}} seconds": "Zurück {{seconds}} Sekunden"
});